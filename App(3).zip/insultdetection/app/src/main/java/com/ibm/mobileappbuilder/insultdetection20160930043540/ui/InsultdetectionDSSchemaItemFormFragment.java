
package com.ibm.mobileappbuilder.insultdetection20160930043540.ui;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.insultdetection20160930043540.presenters.FeedbackFormPresenter;
import com.ibm.mobileappbuilder.insultdetection20160930043540.R;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.ImagePicker;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import java.io.IOException;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.insultdetection20160930043540.ds.InsultdetectionDSSchemaItem;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.cloudant.factory.CloudantDatastoresFactory;
import java.net.URI;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class InsultdetectionDSSchemaItemFormFragment extends FormFragment<InsultdetectionDSSchemaItem> {

    private CrudDatasource<InsultdetectionDSSchemaItem> datasource;

    public static InsultdetectionDSSchemaItemFormFragment newInstance(Bundle args){
        InsultdetectionDSSchemaItemFormFragment fr = new InsultdetectionDSSchemaItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public InsultdetectionDSSchemaItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new FeedbackFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("feedback"));
    }

    @Override
    protected InsultdetectionDSSchemaItem newItem() {
        return new InsultdetectionDSSchemaItem();
    }

    @Override
    protected int getLayout() {
        return R.layout.feedback_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final InsultdetectionDSSchemaItem item, View view) {
        
        bindString(R.id.image, item.image, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.image = s.toString();
            }
        });
        
        
        bindString(R.id.news, item.news, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.news = s.toString();
            }
        });
        
        
        bindString(R.id.title, item.title, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.title = s.toString();
            }
        });
        
        
        bindString(R.id.comments, item.comments, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.comments = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<InsultdetectionDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CloudantDatasource.cloudantDatasource(
              CloudantDatastoresFactory.create("insultdetection"),
              URI.create("https://58fcb80c-7461-4cb4-86c6-b0342c1aca38-bluemix:632516a0670a514b4ca52e9b44653a8b85dd2106be3cb56e29d8fc4718b46c70@58fcb80c-7461-4cb4-86c6-b0342c1aca38-bluemix.cloudant.com/insultdetection"),
              InsultdetectionDSSchemaItem.class,
              new SearchOptions(),
              null
      );
        return datasource;
    }
}

