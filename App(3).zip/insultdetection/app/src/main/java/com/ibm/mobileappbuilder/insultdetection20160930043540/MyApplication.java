

package com.ibm.mobileappbuilder.insultdetection20160930043540;

import android.app.Application;
import ibmmobileappbuilder.injectors.ApplicationInjector;
import android.support.multidex.MultiDexApplication;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.cloudant.factory.CloudantDatabaseSyncerFactory;
import java.net.URI;


/**
 * You can use this as a global place to keep application-level resources
 * such as singletons, services, etc.
 */
public class MyApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        ApplicationInjector.setApplicationContext(this);
        AnalyticsReporterInjector.analyticsReporter(this).init(this);
        //Syncing cloudant ds
        CloudantDatabaseSyncerFactory.instanceFor(
            "insultdetection",
            URI.create("https://58fcb80c-7461-4cb4-86c6-b0342c1aca38-bluemix:632516a0670a514b4ca52e9b44653a8b85dd2106be3cb56e29d8fc4718b46c70@58fcb80c-7461-4cb4-86c6-b0342c1aca38-bluemix.cloudant.com/insultdetection")
        ).sync(null);
          CloudantDatabaseSyncerFactory.instanceFor(
            "prediction",
            URI.create("https://3a3f6cb6-8e4b-4c35-a9ce-f6932567c29d-bluemix:208add3aeacfa068aab8c56c9741fe3fe722be472318d383e760f2b1445aa3e1@3a3f6cb6-8e4b-4c35-a9ce-f6932567c29d-bluemix.cloudant.com/prediction")
        ).sync(null);
      }
}

