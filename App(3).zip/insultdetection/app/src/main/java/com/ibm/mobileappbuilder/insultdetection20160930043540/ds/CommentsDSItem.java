
package com.ibm.mobileappbuilder.insultdetection20160930043540.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class CommentsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("sam0") public String sam0;
    @SerializedName("raj0") public String raj0;
    @SerializedName("raj1") public String raj1;
    @SerializedName("ravi0") public String ravi0;
    @SerializedName("sri0") public String sri0;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(sam0);
        dest.writeString(raj0);
        dest.writeString(raj1);
        dest.writeString(ravi0);
        dest.writeString(sri0);
        dest.writeString(id);
    }

    public static final Creator<CommentsDSItem> CREATOR = new Creator<CommentsDSItem>() {
        @Override
        public CommentsDSItem createFromParcel(Parcel in) {
            CommentsDSItem item = new CommentsDSItem();

            item.sam0 = in.readString();
            item.raj0 = in.readString();
            item.raj1 = in.readString();
            item.ravi0 = in.readString();
            item.sri0 = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public CommentsDSItem[] newArray(int size) {
            return new CommentsDSItem[size];
        }
    };

}


