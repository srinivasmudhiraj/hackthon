
package com.ibm.mobileappbuilder.insultdetection20160930043540.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.insultdetection20160930043540.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "CommentsDSService" REST Service implementation
 */
public class CommentsDSService extends RestService<CommentsDSServiceRest>{

    public static CommentsDSService getInstance(){
          return new CommentsDSService();
    }

    private CommentsDSService() {
        super(CommentsDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "ciYRZnHu";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ee248a11cb3e03009e8fc5",
                path,
                "apikey=ciYRZnHu");
    }

}

