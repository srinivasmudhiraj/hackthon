
package com.ibm.mobileappbuilder.insultdetection20160930043540.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface CommentsDSServiceRest{

	@GET("/app/57ee248a11cb3e03009e8fc5/r/commentsDS")
	void queryCommentsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<CommentsDSItem>> cb);

	@GET("/app/57ee248a11cb3e03009e8fc5/r/commentsDS/{id}")
	void getCommentsDSItemById(@Path("id") String id, Callback<CommentsDSItem> cb);

	@DELETE("/app/57ee248a11cb3e03009e8fc5/r/commentsDS/{id}")
  void deleteCommentsDSItemById(@Path("id") String id, Callback<CommentsDSItem> cb);

  @POST("/app/57ee248a11cb3e03009e8fc5/r/commentsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<CommentsDSItem>> cb);

  @POST("/app/57ee248a11cb3e03009e8fc5/r/commentsDS")
  void createCommentsDSItem(@Body CommentsDSItem item, Callback<CommentsDSItem> cb);

  @PUT("/app/57ee248a11cb3e03009e8fc5/r/commentsDS/{id}")
  void updateCommentsDSItem(@Path("id") String id, @Body CommentsDSItem item, Callback<CommentsDSItem> cb);

  @GET("/app/57ee248a11cb3e03009e8fc5/r/commentsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

