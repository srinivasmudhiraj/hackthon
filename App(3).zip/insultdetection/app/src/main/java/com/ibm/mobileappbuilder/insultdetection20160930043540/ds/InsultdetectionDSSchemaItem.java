
package com.ibm.mobileappbuilder.insultdetection20160930043540.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class InsultdetectionDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("image") public String image;
    @SerializedName("News") public String news;
    @SerializedName("Title") public String title;
    @SerializedName("comments") public String comments;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(image);
        dest.writeString(news);
        dest.writeString(title);
        dest.writeString(comments);
    }

    public static final Creator<InsultdetectionDSSchemaItem> CREATOR = new Creator<InsultdetectionDSSchemaItem>() {
        @Override
        public InsultdetectionDSSchemaItem createFromParcel(Parcel in) {
            InsultdetectionDSSchemaItem item = new InsultdetectionDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.image = in.readString();
            item.news = in.readString();
            item.title = in.readString();
            item.comments = in.readString();
            return item;
        }

        @Override
        public InsultdetectionDSSchemaItem[] newArray(int size) {
            return new InsultdetectionDSSchemaItem[size];
        }
    };
}


