
package com.ibm.mobileappbuilder.insultdetection20160930043540.presenters;

import com.ibm.mobileappbuilder.insultdetection20160930043540.R;
import com.ibm.mobileappbuilder.insultdetection20160930043540.ds.InsultdetectionDSSchemaItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;
import java.util.Map;
import java.util.HashMap;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;

public class FeedbackDetailPresenter extends BasePresenter implements DetailCrudPresenter<InsultdetectionDSSchemaItem>,
      Datasource.Listener<InsultdetectionDSSchemaItem> {

    private final CrudDatasource<InsultdetectionDSSchemaItem> datasource;
    private final DetailView view;

    public FeedbackDetailPresenter(CrudDatasource<InsultdetectionDSSchemaItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(InsultdetectionDSSchemaItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(InsultdetectionDSSchemaItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(InsultdetectionDSSchemaItem item) {
        logCrudAction("deleted", item.getIdentifiableId());
        view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
    private void logCrudAction(String action, String id) {
      Map<String, String> paramsMap = new HashMap<>(3);
      //action will be one of created, updated or deleted
      paramsMap.put("action", action);
      paramsMap.put("entity", "InsultdetectionDSSchemaItem");
      paramsMap.put("identifier", id);

      AnalyticsReporterInjector.analyticsReporter().sendEvent(paramsMap);
    }
}

